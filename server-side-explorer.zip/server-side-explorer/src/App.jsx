import { useState } from 'react';
import Navbar from './components/Navbar';
import RequestSimulator from './components/RequestSimulator';
import Logs from './components/Logs';
import CodeViewer from './components/CodeViewer';
import Quiz from './components/Quiz';
import Footer from './components/Footer';

function App() {
  const [tab, setTab] = useState('home');

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar setTab={setTab} />
      <div className="p-4">
        {tab === 'home' && (
          <div className="text-center text-xl font-semibold">
            Welcome to <span className="text-blue-600">Server-Side Explorer</span>
          </div>
        )}
        {tab === 'simulate' && <RequestSimulator />}
        {tab === 'logs' && <Logs />}
        {tab === 'code' && <CodeViewer />}
        {tab === 'quiz' && <Quiz />}
      </div>
      <Footer />
    </div>
  );
}

export default App;
