import { PrismLight as SyntaxHighlighter } from 'react-syntax-highlighter';
import oneDark from 'react-syntax-highlighter/dist/cjs/styles/prism/one-dark';

const code = `const express = require('express');
const app = express();

app.get('/api/data', (req, res) => {
  res.send({ message: 'Hello from server!' });
});

app.listen(3000, () => {
  console.log('Server is running...');
});`;

function CodeViewer() {
  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold mb-4">Express.js Code Example</h2>
      <SyntaxHighlighter language="javascript" style={oneDark}>
        {code}
      </SyntaxHighlighter>
    </div>
  );
}

export default CodeViewer;
