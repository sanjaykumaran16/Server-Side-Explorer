function Footer() {
  return (
    <footer className="text-center py-4 mt-10 bg-blue-800 text-white">
      Built by Sanjay Kumaran | © 2025
    </footer>
  );
}

export default Footer;