import { useState } from 'react';

function RequestSimulator() {
  const [output, setOutput] = useState('');

  const simulateRequest = (method) => {
    setOutput(`🔁 ${method} request sent...\n✅ Response: 200 OK from Server`);
  };

  return (
    <div className="bg-white p-6 rounded shadow text-center">
      <h2 className="text-xl font-bold mb-4">Simulate API Request</h2>
      <div className="space-x-4">
        <button onClick={() => simulateRequest('GET')} className="bg-green-600 px-4 py-2 rounded text-white">GET</button>
        <button onClick={() => simulateRequest('POST')} className="bg-blue-600 px-4 py-2 rounded text-white">POST</button>
      </div>
      <pre className="mt-5 bg-black text-green-300 p-4 rounded">{output}</pre>
    </div>
  );
}

export default RequestSimulator;
