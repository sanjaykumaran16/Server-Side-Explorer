function Navbar({ setTab }) {
  return (
    <nav className="flex justify-center gap-4 p-4 bg-blue-800 text-white font-medium">
      {['home', 'simulate', 'logs', 'code', 'quiz'].map(tab => (
        <button key={tab} onClick={() => setTab(tab)} className="hover:underline capitalize">
          {tab}
        </button>
      ))}
    </nav>
  );
}

export default Navbar;