import { useEffect, useState } from 'react';

function Logs() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const time = new Date().toLocaleTimeString();
      setLogs(prev => [...prev.slice(-6), `📘 Server received request at ${time}`]);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold mb-4">Server Logs</h2>
      <div className="bg-gray-900 text-green-400 p-4 h-48 overflow-y-scroll rounded">
        {logs.map((log, idx) => <div key={idx}>{log}</div>)}
      </div>
    </div>
  );
}

export default Logs;
