import { useState } from 'react';

function Quiz() {
  const [answer, setAnswer] = useState('');
  const [result, setResult] = useState('');

  const handleSubmit = () => {
    setResult(answer === 'b'
      ? '✅ Correct! Server-side rendering happens on the server.'
      : '❌ Incorrect. Try again!');
  };

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold mb-4">Quiz</h2>
      <p className="mb-3">Where does server-side rendering happen?</p>
      <div className="space-y-2">
        <label className="block"><input type="radio" name="q1" value="a" onChange={e => setAnswer(e.target.value)} /> Client</label>
        <label className="block"><input type="radio" name="q1" value="b" onChange={e => setAnswer(e.target.value)} /> Server</label>
        <label className="block"><input type="radio" name="q1" value="c" onChange={e => setAnswer(e.target.value)} /> Browser Plugin</label>
      </div>
      <button onClick={handleSubmit} className="mt-3 bg-blue-600 text-white px-4 py-2 rounded">Submit</button>
      <p className="mt-3">{result}</p>
    </div>
  );
}

export default Quiz;
